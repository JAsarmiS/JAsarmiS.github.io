#!/usr/bin/python3
import sys

equipo_actual = None
suma_actual = 0

for linea in sys.stdin:
    linea = linea.strip()
    if not linea:
        continue
    equipo, puntos = linea.split("\t")
    puntos = int(puntos)

    if equipo_actual == equipo:
        suma_actual += puntos
    else:
        if equipo_actual is not None:
            print("%s\t%d" % (equipo_actual, suma_actual))
        equipo_actual = equipo
        suma_actual = puntos

if equipo_actual is not None:
    print("%s\t%d" % (equipo_actual, suma_actual))
