from pyspark import SparkContext
import sys

def main():
    if len(sys.argv) != 3:
        print("Uso: spark-submit CategoriaDeVideosMasVista.py <input_folder> <output_folder>")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]

    sc = SparkContext(appName="CategoriaDeVideosMasVista")

    lines = sc.textFile(input_path)

    def parse_line(line):
        fields = line.split("\t")
        if len(fields) < 6:
            fields = line.split(" ")
        if len(fields) >= 6:
            try:
                categoria = fields[3]
                visitas = int(fields[5])
                return [(categoria, visitas)]
            except ValueError:
                return []
        return []

    best = (lines
            .flatMap(parse_line)
            .reduceByKey(lambda a, b: a + b)
            .reduce(lambda a, b: a if a[1] >= b[1] else b))

    sc.parallelize([f"{best[0]};{best[1]}"]).saveAsTextFile(output_path)

    sc.stop()

if __name__ == "__main__":
    main()