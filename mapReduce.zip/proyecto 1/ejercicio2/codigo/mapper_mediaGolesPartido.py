#!/usr/bin/python3
import sys

for linea in sys.stdin:
    linea = linea.strip()

    # Saltar cabecera y líneas vacías
    if "Season" in linea or linea == "":
        continue

    campos = linea.split(",")
    score     = campos[3]   # ej: "1-2"
    local     = campos[5]   # ej: "Mallorca"
    visitante = campos[6]   # ej: "Real Madrid"

    goles_local, goles_visitante = map(int, score.split("-"))

    # Clave: "equipo\tLocal" o "equipo\tVisitante"
    # Valor: "goles\t1"  (goles + contador de partidos)
    print("%s\tLocal\t%d\t1"     % (local,     goles_local))
    print("%s\tVisitante\t%d\t1" % (visitante, goles_visitante))
