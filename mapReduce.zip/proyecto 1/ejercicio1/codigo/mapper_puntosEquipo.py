#!/usr/bin/python3
import sys

for linea in sys.stdin:
    linea = linea.strip()
    if not linea:
        continue
    # Saltamos la cabecera
    if linea.startswith(",Season") or linea.startswith("Season"):
        continue

    campos = linea.split(",")
    if len(campos) < 7:
        continue

    score = campos[3].strip()
    home_team = campos[5].strip()
    away_team = campos[6].strip()

    if "-" not in score:
        continue

    try:
        goles_local, goles_visitante = score.split("-")
        goles_local = int(goles_local)
        goles_visitante = int(goles_visitante)
    except ValueError:
        continue

    if goles_local > goles_visitante:
        print("%s\t%d" % (home_team, 3))
        print("%s\t%d" % (away_team, 0))
    elif goles_local < goles_visitante:
        print("%s\t%d" % (home_team, 0))
        print("%s\t%d" % (away_team, 3))
    else:
        print("%s\t%d" % (home_team, 1))
        print("%s\t%d" % (away_team, 1))
