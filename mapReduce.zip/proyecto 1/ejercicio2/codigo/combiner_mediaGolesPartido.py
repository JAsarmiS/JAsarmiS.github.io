#!/usr/bin/python3
import sys

clave_actual = None
total_goles  = 0
total_partidos = 0

for linea in sys.stdin:
    linea = linea.strip()
    equipo, rol, goles, partidos = linea.split("\t")
    goles    = int(goles)
    partidos = int(partidos)

    clave = equipo + "\t" + rol

    if clave_actual is None:
        clave_actual = clave

    if clave == clave_actual:
        total_goles    += goles
        total_partidos += partidos
    else:
        # Emitir suma parcial
        equipo_actual, rol_actual = clave_actual.split("\t")
        print("%s\t%s\t%d\t%d" % (equipo_actual, rol_actual, total_goles, total_partidos))
        clave_actual   = clave
        total_goles    = goles
        total_partidos = partidos

if clave_actual is not None:
    equipo_actual, rol_actual = clave_actual.split("\t")
    print("%s\t%s\t%d\t%d" % (equipo_actual, rol_actual, total_goles, total_partidos))
