from pyspark import SparkContext
import sys

def main():
    if len(sys.argv) != 3:
        print("Uso: spark-submit personaGastosSinTarjetaCredito.py <input> <output>")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]

    sc = SparkContext(appName="personaGastosSinTarjetaCredito")

    lines = sc.textFile(input_path)
    parsed = lines.map(lambda line: line.split(";"))

    # Todas las personas inicializadas a 0
    all_persons = parsed.map(lambda x: (x[0], 0))

    # Solo gastos que NO son tarjeta de crédito
    non_tdc = (parsed
               .filter(lambda x: x[1] != "Tarjeta de crédito")
               .map(lambda x: (x[0], int(x[2]))))

    # Union y suma: personas sin gasto no-TDC quedan en 0
    result = (all_persons
              .union(non_tdc)
              .reduceByKey(lambda a, b: a + b))

    result.map(lambda x: f"{x[0]};{x[1]}").saveAsTextFile(output_path)

    sc.stop()

if __name__ == "__main__":
    main()