from pyspark import SparkContext
import sys

def main():
    if len(sys.argv) != 2:
        print("Uso: spark-submit personaYMetodosDePago.py <input>")
        sys.exit(1)

    input_path = sys.argv[1]

    sc = SparkContext(appName="personaYMetodosDePago")

    lines = sc.textFile(input_path)
    parsed = lines.map(lambda line: line.split(";"))

    # Todas las personas inicializadas a 0
    all_persons = parsed.map(lambda x: (x[0], 0)).cache()

    # Solo compras con tarjeta de crédito
    tdc = (parsed
           .filter(lambda x: x[1] == "Tarjeta de crédito")
           .map(lambda x: (x[0], int(x[2]))))

    # (a) Compras TDC > 1500
    mayor_1500 = (tdc
                  .filter(lambda x: x[1] > 1500)
                  .map(lambda x: (x[0], 1)))

    result_a = (all_persons
                .union(mayor_1500)
                .reduceByKey(lambda a, b: a + b))

    result_a.map(lambda x: f"{x[0]};{x[1]}").saveAsTextFile("comprasConTDCMayorDe1500")

    # (b) Compras TDC <= 1500
    menor_igual_1500 = (tdc
                        .filter(lambda x: x[1] <= 1500)
                        .map(lambda x: (x[0], 1)))

    result_b = (all_persons
                .union(menor_igual_1500)
                .reduceByKey(lambda a, b: a + b))

    result_b.map(lambda x: f"{x[0]};{x[1]}").saveAsTextFile("comprasConTDCMenoroIgualDe1500")

    sc.stop()

if __name__ == "__main__":
    main()